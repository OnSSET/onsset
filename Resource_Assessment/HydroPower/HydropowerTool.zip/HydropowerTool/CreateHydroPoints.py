def createHydroPoints(rivers, elevation, flowAccu, discharge, interval, points):
    desc = Describe(rivers)
    CreateFeatureclass_management(env.workspace,points,geometry_type='POINT',spatial_reference=desc.spatialReference)
    fid_name = 'river_ID'
    AddField_management(points, fid_name, 'LONG')

    with da.SearchCursor(rivers, ['SHAPE@', desc.OIDFieldName]) as search_cursor:
        with da.InsertCursor(points, ['SHAPE@', fid_name]) as insert_cursor:
            for row in search_cursor:
                line = row[0]

                if line:
                    cur_length = interval
                    max_position = line.length
                    insert_cursor.insertRow([line.firstPoint, row[1]])
                    while cur_length < max_position:
                        insert_cursor.insertRow([line.positionAlongLine(cur_length, False), row[1]])
                        cur_length += interval

    sa.ExtractMultiValuesToPoints(points, [[elevation, 'elev']])

    # calculate the elevation difference between successive points
    AddField_management(points, 'head', 'FLOAT')
    with da.UpdateCursor(points, [fid_name,'elev','head']) as cursor:
        prevFid = 0
        prevElev = 0

        for row in cursor:
            if row[1]: #check to make sure an elevation entry exists
                currentFid = row[0]
                currentElev = row[1]

                if (currentFid == prevFid) and ((prevElev - currentElev) > 0):
                    row[2] = prevElev - currentElev
                else:
                    row[2] = 0

                cursor.updateRow(row)
                prevFid = currentFid
                prevElev = currentElev
            else:
                row[2] = 0
                prevFid = row[0]
                prevElev = 0

    # delete all points where delta_h is 0 or negative
    with da.UpdateCursor(points, 'head') as cursor:
        for row in cursor:
            if row[0] <= 0:
                cursor.deleteRow()

    sa.ExtractMultiValuesToPoints(points, [[discharge, 'discharge_second']])


    # before calculating the power, delete any points that will result in a value absurdly large or small (LONG only goes up to 2 billion)
    # currently set at less than 10 litres/sec, or more than 2000 m^3/sec
    dischargeLowerCutoff = 0.01
    dischargeUpperCutoff = 2000
    with da.UpdateCursor(points, 'discharge_second') as cursor:
        for row in cursor:
            if row[0] < dischargeLowerCutoff or row[0] > dischargeUpperCutoff:
                cursor.deleteRow()

    # calculate the power in watts based on Alex's formula
    # P = rho * g * nt * ng * conv * Q * deltaH
    rho = '1000' # density
    g= '9.81' # gravity
    nt = '0.88' # turbine efficiency
    ng = '0.96' # generator efficiency
    conv = '0.6' # conversion factor for environmental flow deduction
    AddField_management(points, 'power', 'FLOAT')
    CalculateField_management(points, 'power', rho+'*'+g+'*'+nt+'*'+ng+'*'+conv+'* !discharge_second! * !head!', 'PYTHON_9.3')
